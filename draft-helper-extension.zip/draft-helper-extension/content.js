// Draft Room Helper: a side panel for the ESPN fantasy basketball draft room.
// Reads the picks (from the page's pick list, falling back to ESPN's league API through your own logged-in
// session), then shows the best picks for your team, your category balance, live buckets and a league view.
// Nothing leaves your browser: no servers, no accounts, settings saved in chrome.storage.local.
(() => {
  if (window.__draftHelperLoaded) return;
  window.__draftHelperLoaded = true;

  const D = DH_DATA, CATS = D.cats, NC = CATS.length, P = D.players;
  const SLOT_MASK = { PG: 1, SG: 2, SF: 4, PF: 8, C: 16, G: 3, F: 12, UTIL: 31 };
  const POS_BIT = { PG: 1, SG: 2, SF: 4, PF: 8, C: 16 };
  const NEED_WEIGHT = 0.35;

  const normName = s => String(s || "").normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toLowerCase()
    .replace(/[.'’`]/g, "").replace(/-/g, " ").replace(/\b(jr|sr|ii|iii|iv|v)\b/g, "").replace(/\s+/g, " ").trim();
  const byKey = new Map(), byEspn = new Map();
  P.forEach((p, i) => { p.i = i; p.mask = p.p.split("/").reduce((m, x) => m | (POS_BIT[x] || 0), 0) || 4;
    p.k.forEach(k => { if (!byKey.has(k)) byKey.set(k, i); }); if (p.id) byEspn.set(p.id, i); });
  const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  const qs = new URLSearchParams(location.search);
  const leagueId = qs.get("leagueId"), urlTeam = qs.get("teamId") ? Number(qs.get("teamId")) : null;
  const season = Number(qs.get("seasonId")) || D.season;
  const store = (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) ? chrome.storage.local : null;
  const SKEY = "dh:" + (leagueId || "none");
  let prefs = { myTeam: null, slot: null, collapsed: false, tab: "best", view: null };

  // ---------- reading the draft ----------
  let api = null, apiAt = 0;
  async function fetchApi() {
    if (!leagueId) return null;
    const u = `https://lm-api-reads.fantasy.espn.com/apis/v3/games/fba/seasons/${season}/segments/0/leagues/${leagueId}` +
      `?view=mDraftDetail&view=mSettings&view=mTeam`;
    try {
      const r = await fetch(u, { credentials: "include", cache: "no-store" });
      if (!r.ok) return null;
      const j = await r.json();
      const teams = (j.teams || []).map(t => ({ id: t.id, name: (t.name || `${t.location || ""} ${t.nickname || ""}`).trim() }));
      const s = j.settings || {};
      const slots = (s.rosterSettings && s.rosterSettings.lineupSlotCounts) || {};
      const roster = Object.entries(slots).filter(([k]) => k !== "13").reduce((a, [, v]) => a + v, 0);
      return { teams, order: (s.draftSettings && s.draftSettings.pickOrder) || null, nTeams: s.size || teams.length || null,
               roster: roster || null, leagueName: s.name || "",
               picks: ((j.draftDetail && j.draftDetail.picks) || []).filter(p => p.playerId > 0)
                 .map(p => ({ overall: p.overallPickNumber, teamId: p.teamId, espnId: p.playerId })) };
    } catch (e) { return null; }
  }

  function domPicks() {
    const t = document.body.innerText || "";
    const i = t.lastIndexOf("\nPicks\n");
    if (i < 0) return null;
    const L = t.slice(i + 7).split("\n").map(s => s.trim()).filter(Boolean), out = [];
    for (let k = 0; k + 1 < L.length; k++) {
      const m = L[k + 1].match(/^R(\d+), P(\d+) - (.+)$/);
      if (m && L[k].includes(" / ")) { out.push({ round: +m[1], rp: +m[2], team: m[3].trim(), name: L[k].split(" / ")[0].trim() }); k++; }
    }
    return out;
  }

  // ---------- the model ----------
  const S = {};   // current computed state
  function compute() {
    const dom = domPicks();
    const T = (api && api.nTeams) || (dom && dom.length ? Math.max(D.teams, ...dom.filter(p => p.round === 1).map(p => p.rp)) : D.teams);
    const R = (api && api.roster) || D.roster;
    // teams: id -> name
    let teams = api && api.teams.length ? api.teams.map(t => ({ id: String(t.id), name: t.name })) : [];
    const nameToId = new Map(teams.map(t => [normName(t.name), t.id]));
    const picks = [];
    if (dom && dom.length) {
      for (const d of dom) {
        let tid = nameToId.get(normName(d.team));
        if (!tid) { tid = "n:" + d.team; if (!teams.some(t => t.id === tid)) teams.push({ id: tid, name: d.team }); }
        const pi = byKey.get(normName(d.name));
        picks.push({ overall: (d.round - 1) * T + d.rp, round: d.round, rp: d.rp, team: tid, pi: pi ?? -1, name: d.name });
      }
    } else if (api && api.picks.length) {
      for (const a of api.picks) {
        const pi = byEspn.get(a.espnId);
        picks.push({ overall: a.overall, round: Math.ceil(a.overall / T), team: String(a.teamId), pi: pi ?? -1, name: pi != null ? P[pi].n : "#" + a.espnId });
      }
    }
    picks.sort((a, b) => a.overall - b.overall);
    let my = prefs.myTeam || (urlTeam != null ? String(urlTeam) : null);
    if (my && teams.length && !teams.some(t => t.id === my)) my = null;   // no team list from ESPN yet: ask
    // my draft slot: league pick order, else my first-round pick, else what I typed in
    let slot = null;
    if (api && api.order && my && !my.startsWith("n:")) { const k = api.order.indexOf(Number(my)); if (k >= 0) slot = k + 1; }
    if (!slot && my) { const r1 = picks.find(p => p.round === 1 && p.team === my); if (r1) slot = r1.rp; }
    if (!slot && prefs.slot) slot = prefs.slot;
    const taken = new Set(picks.filter(p => p.pi >= 0).map(p => p.pi));
    const rosters = new Map(teams.map(t => [t.id, []]));
    for (const p of picks) { if (!rosters.has(p.team)) rosters.set(p.team, []); if (p.pi >= 0) rosters.get(p.team).push(p.pi); }
    const made = picks.length ? Math.max(picks.length, picks[picks.length - 1].overall) : 0;
    const myPicks = slot ? Array.from({ length: R }, (_, r) => r * T + (r % 2 === 0 ? slot : T + 1 - slot)) : [];
    const next = myPicks.filter(n => n > made);
    Object.assign(S, { T, R, teams, picks, taken, rosters, my, slot, made, myPicks, next, unknown: picks.filter(p => p.pi < 0).map(p => p.name),
                       source: dom && dom.length ? "draft page" : api && api.picks.length ? "ESPN API" : (dom ? "draft page (no picks yet)" : "waiting for the draft room") });
  }

  function parZ(k) {        // average team's category totals after k picks each
    const z = new Float64Array(NC), n = Math.min(P.length, S.T * k);
    for (let i = 0; i < n; i++) for (let c = 0; c < NC; c++) z[c] += P[i].z[c];
    for (let c = 0; c < NC; c++) z[c] /= S.T;
    return z;
  }
  function teamZ(roster) { const z = new Float64Array(NC); for (const i of roster) for (let c = 0; c < NC; c++) z[c] += P[i].z[c]; return z; }

  function filledSlots(masks) {   // max starters that can be filled (bipartite matching)
    const sm = D.slots.map(s => SLOT_MASK[s]), owner = new Array(sm.length).fill(-1);
    const go = (pi, seen) => { for (let s = 0; s < sm.length; s++) if ((sm[s] & masks[pi]) && !seen[s]) { seen[s] = true;
      if (owner[s] < 0 || go(owner[s], seen)) { owner[s] = pi; return true; } } return false; };
    let n = 0; for (let i = 0; i < masks.length; i++) if (go(i, [])) n++;
    return n;
  }
  function openSlots(roster) {
    const sm = D.slots.map(s => SLOT_MASK[s]), owner = new Array(sm.length).fill(-1), masks = roster.map(i => P[i].mask);
    const go = (pi, seen) => { for (let s = 0; s < sm.length; s++) if ((sm[s] & masks[pi]) && !seen[s]) { seen[s] = true;
      if (owner[s] < 0 || go(owner[s], seen)) { owner[s] = pi; return true; } } return false; };
    for (let i = 0; i < masks.length; i++) go(i, []);
    return D.slots.filter((s, k) => owner[k] < 0);
  }

  function advice(teamId) {
    const roster = S.rosters.get(teamId) || [], k = roster.length;
    const gap = new Float64Array(NC), tz = teamZ(roster), pz = parZ(Math.max(1, k));
    for (let c = 0; c < NC; c++) gap[c] = k ? tz[c] - pz[c] : 0;
    const need = Array.from(gap, g => Math.max(0, -g)), mx = Math.max(...need, 1e-9);
    const left = S.R - k - 1, nextPick = S.next[0], after = S.next[1];
    const cOnly = roster.filter(i => P[i].mask === 16).length;
    const out = [];
    for (const p of P) {
      if (S.taken.has(p.i)) continue;
      if (p.mask === 16 && cOnly >= 4) continue;
      if (D.slots.length - filledSlots([...roster, p.i].map(i => P[i].mask)) > Math.max(0, left)) continue;
      let fit = p.v; for (let c = 0; c < NC; c++) fit += NEED_WEIGHT * p.z[c] * need[c] / mx;
      out.push({ p, fit });
    }
    out.sort((a, b) => b.fit - a.fit);
    return { gap, roster, list: out.slice(0, 12), nextPick, after };
  }

  // ---------- panel ----------
  const host = document.createElement("div");
  host.id = "draft-helper-host";
  document.documentElement.appendChild(host);
  const root = host.attachShadow({ mode: "open" });
  root.innerHTML = `<style>
    :host { all: initial; }
    .wrap { position: fixed; top: 64px; right: 10px; width: 400px; max-height: calc(100vh - 84px); z-index: 2147483000; display: flex; flex-direction: column;
      background: #fff; color: #1d2433; border: 1px solid #c9d2e0; border-radius: 10px; box-shadow: 0 8px 28px rgba(15,25,45,.22);
      font: 12.5px/1.4 system-ui, -apple-system, "Segoe UI", Roboto, Arial, sans-serif; }
    .wrap.min { width: auto; }
    .hd { display: flex; align-items: center; gap: 8px; padding: 8px 10px; background: #1f2a44; color: #fff; border-radius: 9px 9px 0 0; cursor: default; }
    .wrap.min .hd { border-radius: 9px; }
    .hd b { font-size: 13px; letter-spacing: .02em; }
    .hd .st { font-size: 11px; opacity: .8; margin-left: auto; }
    .hd button { background: transparent; border: 1px solid rgba(255,255,255,.4); color: #fff; border-radius: 6px; padding: 1px 8px; cursor: pointer; font: inherit; }
    .tabs { display: flex; border-bottom: 1px solid #e3e8f0; }
    .tabs button { flex: 1; background: none; border: 0; border-bottom: 2px solid transparent; padding: 7px 4px; cursor: pointer; font: 600 12px system-ui, sans-serif; color: #5b6578; }
    .tabs button.on { color: #1f2a44; border-bottom-color: #2f6fed; }
    #main { display: flex; flex-direction: column; min-height: 0; flex: 1; }
    .body { overflow: auto; padding: 8px 10px 12px; flex: 1; min-height: 0; }
    .row { display: flex; gap: 6px; align-items: center; flex-wrap: wrap; margin: 4px 0 8px; }
    select, input { font: inherit; padding: 2px 4px; border: 1px solid #c9d2e0; border-radius: 5px; background: #fff; color: inherit; }
    .note { color: #5b6578; font-size: 11.5px; }
    .big { font-size: 13px; font-weight: 700; margin: 2px 0 6px; }
    table { width: 100%; border-collapse: collapse; }
    th { text-align: left; font-size: 10.5px; color: #5b6578; font-weight: 600; padding: 3px 4px; border-bottom: 1px solid #e3e8f0; position: sticky; top: 0; background: #fff; }
    td { padding: 4px; border-bottom: 1px solid #f0f2f6; vertical-align: top; }
    td.n { font-weight: 600; }
    .sub { display: block; font-weight: 400; color: #5b6578; font-size: 11px; }
    .tag { display: inline-block; font-size: 10px; font-weight: 700; padding: 0 5px; border-radius: 4px; margin-left: 4px; border: 1px solid; }
    .warn { color: #b42318; border-color: #f2b8b5; } .ok { color: #0a7a3d; border-color: #a6dcbc; } .info { color: #2f6fed; border-color: #b9cff2; }
    .g { color: #0a7a3d; } .r { color: #b42318; }
    .bars .b { display: grid; grid-template-columns: 38px 1fr 42px; align-items: center; gap: 6px; margin: 3px 0; }
    .bar { position: relative; height: 10px; background: #f0f2f6; border-radius: 3px; }
    .bar i { position: absolute; top: 0; bottom: 0; border-radius: 3px; }
    .bar:after { content: ""; position: absolute; left: 50%; top: -2px; bottom: -2px; width: 1px; background: #9aa5b8; }
    .bk { border: 1px solid #e3e8f0; border-radius: 8px; margin: 6px 0; }
    .bk.live { border-color: #2f9e5b; box-shadow: 0 0 0 2px #c6efce; }
    .bk.done { opacity: .5; }
    .bk h4 { margin: 0; padding: 5px 8px; font-size: 12px; background: #f5f7fb; border-radius: 8px 8px 0 0; display: flex; gap: 6px; }
    .bk h4 span { margin-left: auto; font-weight: 500; color: #5b6578; }
    .bk ul { list-style: none; margin: 0; padding: 4px 8px 6px; columns: 2; column-gap: 10px; }
    .bk li { break-inside: avoid; padding: 1px 0; }
    .bk li.gone { text-decoration: line-through; color: #9aa5b8; }
    .bk li.mine { color: #2f6fed; font-weight: 700; text-decoration: none; }
    .bk li.punt { color: #b42318; }
    .grid td, .grid th { text-align: center; padding: 3px 2px; font-size: 11px; }
    .grid td.l, .grid th.l { text-align: left; }
    .grid tr.me td { font-weight: 700; }
    .hide { display: none !important; }
  </style>
  <div class="wrap" id="wrap">
    <div class="hd"><b>Draft Helper</b><span class="st" id="st"></span><button id="tog" title="Collapse or expand">–</button></div>
    <div id="main">
      <div class="tabs"><button data-t="best">Best pick</button><button data-t="team">My team</button><button data-t="buckets">Buckets</button><button data-t="league">League</button></div>
      <div class="body" id="body"></div>
    </div>
  </div>`;
  const $ = id => root.getElementById(id);
  root.querySelectorAll(".tabs button").forEach(b => b.onclick = () => { prefs.tab = b.dataset.t; save(); render(true); });
  $("tog").onclick = () => { prefs.collapsed = !prefs.collapsed; save(); render(true); };

  function save() { if (store) store.set({ [SKEY]: prefs }); }
  const teamName = id => (S.teams.find(t => t.id === id) || {}).name || (id ? "Team " + id.replace(/^n:/, "") : "?");

  function teamPicker(label, val, onchange) {
    const opts = S.teams.map(t => `<option value="${esc(t.id)}"${t.id === val ? " selected" : ""}>${esc(t.name)}</option>`).join("");
    return `<label>${label} <select data-pick="${onchange}"><option value="">choose…</option>${opts}</select></label>`;
  }

  function renderBest() {
    if (!S.my) return `<div class="row">${teamPicker("Which team is yours?", S.my, "my")}</div><p class="note">Pick your team once; it's remembered for this league.</p>`;
    if (!S.slot) return `<div class="row">${teamPicker("Your team", S.my, "my")}</div>
      <div class="row"><label>Your draft slot <input type="number" min="1" max="${S.T}" id="slotIn" style="width:56px"></label></div>
      <p class="note">ESPN hasn't shared the pick order yet. Type your slot, or it fills in after your first pick.</p>`;
    if (!S.next.length) return `<p class="big">Your roster is full.</p>`;
    const a = advice(S.my), away = a.nextPick - S.made - 1;
    const open = openSlots(a.roster);
    const topBucket = liveBuckets()[0];
    const rows = a.list.slice(0, 10).map(({ p, fit }) => {
      const helps = CATS.filter((c, j) => p.z[j] >= 0.8), hurts = CATS.filter((c, j) => p.z[j] <= -0.8);
      let risk = "";
      if (p.adp != null && p.adp < a.nextPick) risk = `<span class="tag warn" title="League ADP ${p.adp}">likely gone</span>`;
      else if (p.adp != null && a.after && p.adp < a.after) risk = `<span class="tag info">won't come back</span>`;
      const fills = open.filter(s => s !== "UTIL" && (SLOT_MASK[s] & p.mask));
      return `<tr><td>${p.r}</td><td class="n">${esc(p.n)}${fills.length ? `<span class="tag ok">fills ${fills.join("/")}</span>` : ""}${risk}
        <span class="sub">${esc(p.p)} · ${esc(p.t || "")} · B${p.b ?? "–"} · ADP ${p.adp ?? "–"}</span>
        <span class="sub"><span class="g">${helps.join(" ")}</span>${hurts.length ? ` · <span class="r">${hurts.join(" ")}</span>` : ""}</span></td><td>${fit.toFixed(1)}</td></tr>`;
    }).join("");
    return `<p class="big">Your next pick: #${a.nextPick} <span class="note">(${away <= 0 ? "you're on the clock" : away + " picks away"}, slot ${S.slot})</span></p>
      ${topBucket ? `<p class="note">Highest bucket left: <b>Bucket ${topBucket.n}</b>: ${topBucket.left.slice(0, 4).map(i => esc(P[i].n)).join(", ")}${topBucket.left.length > 4 ? "…" : ""}</p>` : ""}
      <p class="note">Open starting slots: ${open.join(", ") || "none, bench now"}</p>
      <table><thead><tr><th>Rk</th><th>Player</th><th title="Value plus a lean toward your weak categories">Fit</th></tr></thead><tbody>${rows}</tbody></table>
      <p class="note">Fit = board value, leaning toward categories your team is behind in. "Likely gone" = league ADP is before your pick.</p>`;
  }

  function renderTeam() {
    const id = prefs.view || S.my;
    if (!id) return `<div class="row">${teamPicker("Show team", id, "view")}</div>`;
    const roster = S.rosters.get(id) || [], k = roster.length;
    const tz = teamZ(roster), pz = parZ(Math.max(1, k));
    const bars = CATS.map((c, j) => { const g = k ? tz[j] - pz[j] : 0, w = Math.min(50, Math.abs(g) * 8);
      return `<div class="b"><span>${c}</span><div class="bar"><i style="${g >= 0 ? `left:50%;width:${w}%;background:#2f9e5b` : `right:50%;width:${w}%;background:#d9534f`}"></i></div><span class="${g >= 0 ? "g" : "r"}">${g >= 0 ? "+" : ""}${g.toFixed(1)}</span></div>`; }).join("");
    const list = roster.map(i => { const p = P[i];
      const helps = CATS.filter((c, j) => p.z[j] >= 0.8), hurts = CATS.filter((c, j) => p.z[j] <= -0.8);
      return `<tr><td class="n">${esc(p.n)}<span class="sub">${esc(p.p)} · ${esc(p.t || "")} · rank ${p.r}</span></td><td><span class="g">${helps.join(" ")}</span>${hurts.length ? `<br><span class="r">${hurts.join(" ")}</span>` : ""}</td></tr>`; }).join("");
    const open = openSlots(roster);
    return `<div class="row">${teamPicker("Team", id, "view")}</div>
      <p class="note">${k} of ${S.R} picked · open starting slots: ${open.join(", ") || "none"}. Bars compare this team with an average team after the same number of picks.</p>
      <div class="bars">${bars}</div>
      <table style="margin-top:8px"><thead><tr><th>Player</th><th>Helps / hurts</th></tr></thead><tbody>${list || `<tr><td colspan="2" class="note">No picks yet.</td></tr>`}</tbody></table>`;
  }

  function liveBuckets() {
    const out = [];
    for (const b of D.buckets) {
      const left = P.filter(p => p.b === b.n && !S.taken.has(p.i)).map(p => p.i);
      if (left.length) out.push({ n: b.n, left });
    }
    return out;
  }

  function renderBuckets() {
    const mine = new Set(S.my ? S.rosters.get(S.my) || [] : []);
    const owner = new Map(S.picks.filter(p => p.pi >= 0).map(p => [p.pi, p.team]));
    const nxt = S.next[0];
    const block = (title, sub, members, cls) => {
      const left = members.filter(m => !S.taken.has(m.i)).length;
      const lis = members.map(m => { const p = P[m.i], gone = S.taken.has(p.i);
        const c = [gone ? "gone" : "", mine.has(p.i) ? "mine" : "", m.punt ? "punt" : ""].join(" ");
        const who = gone ? ` title="${esc(teamName(owner.get(p.i)))}"` : "";
        return `<li class="${c}"${who}>${esc(p.n)}${m.punt ? ` (${esc(m.punt)})` : ""}${m.extra ? ` <span class="note">${esc(m.extra)}</span>` : ""}</li>`; }).join("");
      return `<div class="bk ${cls}${left ? "" : " done"}"><h4>${title}<span>${left ? `${sub} · ${left}/${members.length} left` : "all gone"}</span></h4>${left ? `<ul>${lis}</ul>` : ""}</div>`;
    };
    let html = `<p class="note">Struck through = taken (hover for who). Blue = yours. Red = only worth that bucket if you punt the category shown. Green outline = league ADP has this bucket going at your next pick.</p>`;
    for (const b of D.buckets) {
      const members = P.filter(p => p.b === b.n).map(p => ({ i: p.i }))
        .concat(P.filter(p => p.pt && p.pt[0] === b.n).map(p => ({ i: p.i, punt: p.pt[1] })));
      if (!members.length) continue;
      const live = nxt && nxt >= b.adpLo && nxt <= b.adpHi ? " live" : "";
      html += block(`Bucket ${b.n}`, `ADP ${b.adpLo}-${b.adpHi}`, members, live);
    }
    const health = P.filter(p => p.b === "H").map(p => ({ i: p.i, extra: `from ${p.hp}+` }));
    if (health.length) html += block("Health bucket", "per-game studs, injury risk", health, "");
    const fliers = P.filter(p => p.fl).map(p => ({ i: p.i }));
    if (fliers.length) html += block("Fliers (rounds 8-10)", "upside", fliers, "");
    return html;
  }

  function renderLeague() {
    const ids = S.teams.map(t => t.id).filter(id => (S.rosters.get(id) || []).length);
    if (!ids.length) return `<p class="note">No picks yet.</p>`;
    const Z = new Map(ids.map(id => [id, teamZ(S.rosters.get(id))]));
    const rank = (id, j) => 1 + ids.filter(o => Z.get(o)[j] > Z.get(id)[j]).length;
    const tot = id => Z.get(id).reduce((a, b) => a + b, 0);
    const sorted = ids.slice().sort((a, b) => tot(b) - tot(a));
    const n = ids.length;
    const cell = r => { const t = (r - 1) / Math.max(1, n - 1); const col = t < 0.34 ? "#c6efce" : t > 0.66 ? "#f8cbad" : "#fff"; return `<td style="background:${col}">${r}</td>`; };
    const rows = sorted.map((id, k) => `<tr class="${id === S.my ? "me" : ""}"><td class="l"><a href="#" data-view="${esc(id)}">${esc(teamName(id))}</a></td>${CATS.map((c, j) => cell(rank(id, j))).join("")}<td>${k + 1}</td></tr>`).join("");
    return `<p class="note">Rank in each category by drafted players' scores (1 = best; TO already counts fewer as better). Click a team to open its team page.</p>
      <div style="overflow:auto"><table class="grid"><thead><tr><th class="l">Team</th>${CATS.map(c => `<th>${c}</th>`).join("")}<th>All</th></tr></thead><tbody>${rows}</tbody></table></div>`;
  }

  let lastSig = "", lastTab = "";
  function render(force) {
    compute();
    const sig = [S.picks.length, S.made, S.my, S.slot, prefs.tab, prefs.view, prefs.collapsed, S.teams.length].join("|");
    $("st").textContent = `${S.made}/${S.T * S.R} picks · ${S.source}`;
    if (!force && sig === lastSig) return;
    lastSig = sig;
    $("wrap").classList.toggle("min", prefs.collapsed);
    $("main").classList.toggle("hide", prefs.collapsed);
    $("tog").textContent = prefs.collapsed ? "+" : "–";
    if (prefs.collapsed) return;
    root.querySelectorAll(".tabs button").forEach(b => b.classList.toggle("on", b.dataset.t === prefs.tab));
    const body = $("body"), y = body.scrollTop;
    body.innerHTML = { best: renderBest, team: renderTeam, buckets: renderBuckets, league: renderLeague }[prefs.tab]()
      + (S.unknown.length ? `<p class="note">Not on our board: ${S.unknown.slice(-6).map(esc).join(", ")}</p>` : "")
      + `<p class="note" style="margin-top:10px">Board built ${esc(D.built)} · ${D.teams}-team H2H ${NC}-cat (${CATS.join(", ")}).</p>`;
    if (prefs.tab !== lastTab && prefs.tab === "buckets") {   // jump to the first bucket with players left
      const first = body.querySelector(".bk:not(.done)"); body.scrollTop = first ? first.offsetTop - body.offsetTop - 6 : 0;
    } else if (prefs.tab === lastTab) body.scrollTop = y; else body.scrollTop = 0;
    lastTab = prefs.tab;
    body.querySelectorAll("select[data-pick]").forEach(s => s.onchange = () => {
      if (s.dataset.pick === "my") prefs.myTeam = s.value || null; else prefs.view = s.value || null;
      save(); render(true); });
    const si = body.querySelector("#slotIn"); if (si) si.onchange = () => { const v = +si.value; if (v >= 1 && v <= S.T) { prefs.slot = v; save(); render(true); } };
    body.querySelectorAll("a[data-view]").forEach(a => a.onclick = e => { e.preventDefault(); prefs.view = a.dataset.view; prefs.tab = "team"; save(); render(true); });
  }

  async function tickApi() {
    const now = Date.now();
    const domHas = (domPicks() || []).length > 0;
    // team names + pick order once a minute; picks every 8s only when the page list isn't readable
    if (!api || now - apiAt > (domHas ? 60000 : 8000)) { const a = await fetchApi(); if (a) { api = a; apiAt = now; render(true); } else apiAt = now; }
  }

  const start = () => { render(true); setInterval(() => render(false), 2500); tickApi(); setInterval(tickApi, 4000); };
  if (store) store.get(SKEY, v => { if (v && v[SKEY]) prefs = Object.assign(prefs, v[SKEY]); start(); });
  else start();
})();

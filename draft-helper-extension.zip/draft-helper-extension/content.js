// Draft Helper in the ESPN draft room: reads the picks off the page (falling back to ESPN's league API through
// your own login), draws the panel, and optionally broadcasts the draft to a hosted page friends can open.
(() => {
  if (window.__draftHelperLoaded) return;
  window.__draftHelperLoaded = true;
  const { D, normName, byKey, byEspn, esc, mount, pack } = DraftCore;

  const qs = new URLSearchParams(location.search);
  const leagueId = qs.get("leagueId"), urlTeam = qs.get("teamId");
  const season = Number(qs.get("seasonId")) || D.season;
  const store = (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) ? chrome.storage.local : null;
  const SKEY = "dh:" + (leagueId || "none");
  const prefs = { myTeam: urlTeam || null, slot: null, collapsed: false, tab: "best", view: null, cast: false, topic: null };
  const save = () => { if (store) store.set({ [SKEY]: prefs }); };
  const VIEWER = "https://cuddles-mc.github.io/draft-room/live.html";

  // ---------- reading the draft ----------
  let api = null, apiAt = 0;
  async function fetchApi() {
    if (!leagueId) return null;
    const u = `https://lm-api-reads.fantasy.espn.com/apis/v3/games/fba/seasons/${season}/segments/0/leagues/${leagueId}?view=mDraftDetail&view=mSettings&view=mTeam`;
    try {
      const r = await fetch(u, { credentials: "include", cache: "no-store" });
      if (!r.ok) return null;
      const j = await r.json(), s = j.settings || {};
      const slots = (s.rosterSettings && s.rosterSettings.lineupSlotCounts) || {};
      const roster = Object.entries(slots).filter(([k]) => k !== "13").reduce((a, [, v]) => a + v, 0);
      return { teams: (j.teams || []).map(t => [String(t.id), (t.name || `${t.location || ""} ${t.nickname || ""}`).trim()]),
               order: (s.draftSettings && s.draftSettings.pickOrder) || null, T: s.size || (j.teams || []).length || null,
               R: roster || null, league: s.name || "",
               picks: ((j.draftDetail && j.draftDetail.picks) || []).filter(p => p.playerId > 0)
                 .map(p => [p.overallPickNumber, String(p.teamId), byEspn.get(p.playerId) ?? -1, "#" + p.playerId]) };
    } catch (e) { return null; }
  }
  function domPicks() {
    const t = document.body.innerText || "", i = t.lastIndexOf("\nPicks\n");
    if (i < 0) return null;
    const L = t.slice(i + 7).split("\n").map(s => s.trim()).filter(Boolean), out = [];
    for (let k = 0; k + 1 < L.length; k++) {
      const m = L[k + 1].match(/^R(\d+), P(\d+) - (.+)$/);
      if (m && L[k].includes(" / ")) { out.push({ round: +m[1], rp: +m[2], team: m[3].trim(), name: L[k].split(" / ")[0].trim() }); k++; }
    }
    return out;
  }
  let source = "waiting for the draft room";
  function feedFromPage() {
    const dom = domPicks();
    const T = (api && api.T) || (dom && dom.length ? Math.max(D.teams, ...dom.filter(p => p.round === 1).map(p => p.rp)) : D.teams);
    const teams = api ? api.teams.slice() : [];
    const nameToId = new Map(teams.map(([id, n]) => [normName(n), id]));
    let picks = [];
    if (dom && dom.length) {
      for (const d of dom) {
        let tid = nameToId.get(normName(d.team));
        if (!tid) { tid = "n:" + d.team; teams.push([tid, d.team]); nameToId.set(normName(d.team), tid); }
        picks.push([(d.round - 1) * T + d.rp, tid, byKey.get(normName(d.name)) ?? -1, d.name]);
      }
      source = "draft page";
    } else if (api && api.picks.length) { picks = api.picks; source = "ESPN API"; }
    else source = dom ? "draft room open" : "waiting for the draft room";
    return { v: 1, T, R: (api && api.R) || D.roster, league: (api && api.league) || "", teams, order: api ? api.order : null, picks, built: D.built };
  }

  // ---------- broadcasting to the hosted page (ntfy.sh relay, no account) ----------
  let lastSent = "", lastSentAt = 0, sendTimer = null, sentToday = 0, castStatus = "";
  const today = () => new Date().toISOString().slice(0, 10);
  const newTopic = () => { const a = new Uint8Array(12); crypto.getRandomValues(a); return "dr-" + [...a].map(x => x.toString(16).padStart(2, "0")).join(""); };
  function scheduleCast(feed) {
    if (!prefs.cast || !prefs.topic || !chrome.runtime) return;
    const sig = JSON.stringify([feed.picks.length, feed.picks[feed.picks.length - 1] || null, feed.teams.length, feed.order, prefs.topic]);
    if (sig === lastSent || sendTimer) return;
    // ntfy.sh allows 250 messages a day per sender: at most one every 15s (45s once 180 are used today)
    const gap = sentToday >= 180 ? 45000 : 15000;
    sendTimer = setTimeout(() => {
      sendTimer = null;
      const f = feedFromPage(), body = JSON.stringify(pack({ ...f, at: Date.now() }));
      const s2 = JSON.stringify([f.picks.length, f.picks[f.picks.length - 1] || null, f.teams.length, f.order, prefs.topic]);
      if (body.length > 4000) { castStatus = "draft too big for one message"; return; }
      chrome.runtime.sendMessage({ type: "cast", topic: prefs.topic, body }, res => {
        lastSentAt = Date.now();
        if (res && res.ok) { lastSent = s2; sentToday++; castStatus = "sent " + new Date().toLocaleTimeString();
          if (store) store.set({ "dh:sent": { day: today(), n: sentToday } }); }
        else castStatus = "send failed" + (res && res.status ? ` (${res.status})` : "") + ", will retry";
      });
    }, Math.max(0, lastSentAt + gap - Date.now()));
  }

  const share = {
    label: "Share",
    render(S) {
      const link = prefs.topic ? `${VIEWER}#t=${prefs.topic}` : "";
      const teamLinks = prefs.topic && S.teams.length ? S.teams.map(t => `<tr><td>${esc(t.name)}</td><td style="text-align:right"><button class="btn ghost" data-copy="${esc(link + "&team=" + encodeURIComponent(t.id))}">Copy link</button></td></tr>`).join("") : "";
      return `<p class="big">Share this draft live</p>
        <p class="note">Sends the draft to a web page anyone can open on a phone or browser, no extension needed. Each person picks their team there (or gets a personal link below) and sees their own best pick, team balance and buckets.</p>
        <div class="row"><label><input type="checkbox" id="castOn"${prefs.cast ? " checked" : ""}> Broadcast this draft</label></div>
        ${prefs.cast ? `<div class="row"><code>${esc(link)}</code></div>
          <div class="row"><button class="btn" data-copy="${esc(link)}">Copy link</button><button class="btn ghost" id="newTopic">New link</button></div>
          <p class="note">Status: ${esc(castStatus || "waiting for a change")} · ${sentToday}/250 updates used today</p>
          ${teamLinks ? `<p class="note" style="margin-top:8px">Personal links (open straight to that team):</p><table>${teamLinks}</table>` : ""}` : ""}
        <p class="note" style="margin-top:8px">Updates go through ntfy.sh, a free public relay. Anyone with the link can see the picks; nothing else is sent. At most one update every 15 seconds.</p>`;
    },
    bind(body) {
      const on = body.querySelector("#castOn");
      if (on) on.onchange = () => { prefs.cast = on.checked; if (prefs.cast && !prefs.topic) prefs.topic = newTopic(); lastSent = ""; save(); panel.render(true); };
      const nt = body.querySelector("#newTopic");
      if (nt) nt.onclick = () => { prefs.topic = newTopic(); lastSent = ""; save(); panel.render(true); };
      body.querySelectorAll("[data-copy]").forEach(b => b.onclick = () => { navigator.clipboard.writeText(b.dataset.copy); b.textContent = "Copied"; setTimeout(() => panel.render(true), 1200); });
    },
  };

  // ---------- panel ----------
  const host = document.createElement("div");
  host.id = "draft-helper-host";
  document.documentElement.appendChild(host);
  const root = host.attachShadow({ mode: "open" });
  let feed = null;
  const panel = mount(root, {
    mode: "fixed", prefs, save, extraTabs: { share },
    getFeed: () => feed,
    status: S => `${S.made}/${S.T * S.R} · ${source}${prefs.cast ? " · live" : ""}`,
    sig: () => (prefs.tab === "share" ? castStatus + prefs.cast + prefs.topic + sentToday : ""),
  });
  function tick() { feed = feedFromPage(); panel.render(false); scheduleCast(feed); }
  async function tickApi() {
    const domHas = (domPicks() || []).length > 0, now = Date.now();
    if (!api || now - apiAt > (domHas ? 60000 : 8000)) { apiAt = now; const a = await fetchApi(); if (a) { api = a; tick(); } }
  }
  function start() { feed = feedFromPage(); panel.render(true); setInterval(tick, 2500); tickApi(); setInterval(tickApi, 4000); }
  if (store) store.get([SKEY, "dh:sent"], v => {
    if (v && v[SKEY]) Object.assign(prefs, v[SKEY]);
    if (v && v["dh:sent"] && v["dh:sent"].day === today()) sentToday = v["dh:sent"].n;
    start();
  });
  else start();
})();

// Posts the draft feed to the ntfy.sh relay for the hosted live page (runs outside the ESPN page, so its CSP doesn't apply).
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (!msg || msg.type !== "cast" || !/^dr-[0-9a-f]{24}$/.test(msg.topic || "")) return;
  fetch("https://ntfy.sh/" + msg.topic, { method: "POST", body: msg.body, headers: { "Cache": "yes", "Title": "draft" } })
    .then(r => reply({ ok: r.ok, status: r.status }))
    .catch(() => reply({ ok: false }));
  return true;   // reply asynchronously
});
